#!/usr/bin/env python3

import sys
import time
import serial.tools.list_ports
import os
from collections import namedtuple

#import BW16Flasher from the bw16Flasher.py file in the same directory
from bw16Flasher import BW16Flasher

def find_serial_port_by_pid(pid):
    pid_hex = pid.lower()
    ports = serial.tools.list_ports.comports()
    for port in ports:
        if pid_hex in port.hwid.lower():
            return port.device
    return None


FlashSection = namedtuple('FlashSection', ['start_address', 'binary_file_path'])

# Replace '1a86' with the PID you are looking for
pid = "1a86"
serial_port = find_serial_port_by_pid(pid)

if serial_port:
    print(f"{serial_port}")
    bw16_flasher = BW16Flasher(serial_port)
    bw16_flasher.openSerialPort()

    if "eraseall" in sys.argv:
        ret = bw16_flasher.erase_4M_flash()
        if ret == False:
            print("erase 4M flash failed")
        else:
            print("erase 4M flash success")
    elif "userdata" in sys.argv:
        # get parameter after "userdata"
        if len(sys.argv) < 3:
            print("Usage: python bw16PythonFlash.py userdata <path>")
            sys.exit(1)
        user_data_path = sys.argv[2]
        if not os.path.exists(user_data_path):
            print(f"User data file {user_data_path} does not exist.")
            sys.exit(1)
        # check if file size is bigger than 4096
        if os.path.getsize(user_data_path) > 4096:
            print(f"User data file {user_data_path} is bigger than 4096 bytes.")
            sys.exit(1)

        flash_sections = [
           FlashSection(start_address=0x08201000, binary_file_path=user_data_path)
        ]

        ret = bw16_flasher.flash_4M_flash_with_path_and_offset(flash_sections)
        if ret == False:
            print("flash user data in 4M flash failed")
        else:
            print("flash user data in 4M flash success")
            bw16_flasher.reset()
        
    else:
        script_dir = os.path.dirname(os.path.abspath(__file__))
        km0_bootloader_path = os.path.join(script_dir, "km0_boot_all_modified_4M_flash.bin")
        km4_bootloader_path = os.path.join(script_dir, "km4_boot_all_modified_4M_flash.bin")
        support_bin_dir = os.path.join(script_dir, "support_bin")
        if not os.path.exists(km0_bootloader_path):
            km0_bootloader_path = os.path.join(support_bin_dir, "km0_boot_all_modified_4M_flash.bin")
        if not os.path.exists(km4_bootloader_path):
            km4_bootloader_path = os.path.join(support_bin_dir, "km4_boot_all_modified_4M_flash.bin")
            
        image_path = os.path.join(script_dir, "km0_km4_image2.bin")
        if not os.path.exists(image_path):
            if len(sys.argv) >= 2:
                argv1Str = sys.argv[1]
                #check if argv1Str has .bin and exist
                if argv1Str.endswith(".bin") and os.path.exists(argv1Str):
                    image_path = argv1Str
                    print(f"Using image file {image_path}")
                    
        #create named tuple for the flash parameters
        flash_sections = [
            FlashSection(start_address=0x08000000, binary_file_path=km0_bootloader_path),
            FlashSection(start_address=0x08004000, binary_file_path=km4_bootloader_path),
            FlashSection(start_address=0x08006000, binary_file_path=image_path)
        ]

        ret = bw16_flasher.flash_4M_flash_with_path_and_offset(flash_sections)
        if ret == False:
            print("flash 4M flash failed")
        else:
            print("flash 4M flash success")
            bw16_flasher.reset()

    bw16_flasher.closeSerialPort()

    #play a beep sound
    if sys.platform == "darwin":
        os.system('afplay /System/Library/Sounds/Glass.aiff')

