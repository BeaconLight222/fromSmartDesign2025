import time
import serial.tools.list_ports
import serial
import os
from collections import namedtuple

class BW16Flasher:
    #ameba-arduino-d/Ameba_misc/Autoflash_patch/src/upload_image_tool.cpp
    def __init__(self, serial_port_name):
        self.serial_port_name = serial_port_name
        self.serial_port = None
        self.port_speed_lut = {
            1500000: 0x18,
            1444400: 0x17,
            1382400: 0x16,
            1000000: 0x15,
            921600: 0x14,
            500000: 0x13,
            460800: 0x12,
            380400: 0x11,
            230400: 0x10,
            153600: 0x0F,
            380400: 0x0E,
            128000: 0x0D,
            115200: 0x0C
        }
        self.id = 1
        current_dir = os.path.dirname(os.path.abspath(__file__))
        flash_loader_path = os.path.join(current_dir, "imgtool_flashloader_amebad.bin")
        with open(flash_loader_path, "rb") as f:
            flash_loader = f.read()
        self.flash_loader = list(flash_loader)
        self.flash_loader_addr = 0x082000

    def openSerialPort(self):
        self.serial_port = serial.Serial(self.serial_port_name, 115200, timeout=1)

    def closeSerialPort(self):
        if self.serial_port is not None:
            self.serial_port.close()
            self.serial_port = None


    def reset(self, enter_bootloader=False):
        # // DTR RTS EN BUN
        # //   1  1   1  1
        # //   0  0   1  1
        # //   1  0   0  1
        # //   0  1   1  0

        #open serial port
        if enter_bootloader:
            # set DTR high and RTS low to pull EN low
            self.serial_port.setDTR(False)
            self.serial_port.setRTS(True)
            # wait for 500ms
            time.sleep(0.5)
            # set DTR low and RTS high to pull TX_LOG low
            self.serial_port.setDTR(True)
            self.serial_port.setRTS(False)
            # wait for 200ms
            time.sleep(0.2)
            # set DTR high and RTS high to return to normal
            self.serial_port.setDTR(False)
            self.serial_port.setRTS(False)
            # wait for 500ms
            time.sleep(0.5)
        else:
            # just reset the system
            # set DTR high and RTS low to pull EN low
            self.serial_port.setDTR(False)
            self.serial_port.setRTS(True)
            # wait for 500ms
            time.sleep(0.5)
            # set DTR high and RTS high to return to normal
            self.serial_port.setDTR(False)
            self.serial_port.setRTS(False)

    def change_baudrate(self, baudrate):
        if baudrate in self.port_speed_lut:
            self.clear_input_buffer()
            self.serial_port.write(bytes([0x05,self.port_speed_lut[baudrate]]))
            ret = self.wait_for_response_char(b'\x06')
            if ret == False:
                print("change baudrate failed")
                return False
            self.serial_port.baudrate = baudrate
            self.clear_input_buffer()
            self.serial_port.write(bytes([0x07]))
            #ret = self.wait_for_sync(1)
            ret = self.wait_for_response_char(b'\x06')
            if ret == False:
                print("wait for sync failed")
                return False
            return True

        else:
            print("Unsupported baudrate")

    def enter_bootloader(self):
        self.reset(enter_bootloader=True)

    def wait_for_sync(self, count=1):
        startTime = time.monotonic()
        timeLimit = 3
        receivedLen = 0
        if count <= 0:
            return True
        #print("wait for sync")
        while time.monotonic() - startTime < timeLimit:
            while self.serial_port.in_waiting > 0:
                oneChar = self.serial_port.read(1)
                #print(oneChar.hex())
                if oneChar == b'\x15':
                    receivedLen += 1
                    if receivedLen >= count:
                        return True
            time.sleep(0.001)
        return False
    
    def wait_for_response_char(self, char, timeout=3):
        startTime = time.monotonic()
        while time.monotonic() - startTime < timeout:
            while self.serial_port.in_waiting > 0:
                oneChar = self.serial_port.read(1)
                if oneChar == char:
                    return True
            time.sleep(0.001)
        return False

    def clear_input_buffer(self):
        while self.serial_port.in_waiting > 0:
            self.serial_port.read(1)

    def write_block(self, mcu_addr, data):
        #break data into chunk of 1024 bytes
        chunk_size = 1024
        data_len = len(data)
        num_chunks = (data_len + chunk_size - 1) // chunk_size
        for i in range(num_chunks):
            chunk = data[i*chunk_size:(i+1)*chunk_size]
            chunk_len = len(chunk)
            write_addr = mcu_addr + i * chunk_size
            header = [0x02, self.id, 0xFF-self.id, write_addr & 0xFF, (write_addr >> 8) & 0xFF, (write_addr >> 16) & 0xFF, (write_addr >> 24) & 0xFF]
            if chunk_len < chunk_size:
                chunk = chunk + [0xFF] * (chunk_size - chunk_len)
            checksum = (0xff + sum(header) + sum(chunk)) & 0xFF
            data_to_send = header + chunk + [checksum]
            self.clear_input_buffer()
            self.serial_port.write(bytes(data_to_send))
            ret = self.wait_for_response_char(b'\x06')
            if ret == False:
                print("write block failed")
                return False
            self.id = (self.id + 1) % 256
        return True
    
    def verify_block(self, mcu_addr, data):
        data_len = len(data)
        data_len_padded = ((data_len + 3) // 4) * 4
        difference = data_len_padded - data_len
        if difference > 0:
            data_padded = data + [0x00] * difference
        else:
            data_padded = data
        #now the data_padded is 4 byte aligned of uint8, convert to uint32
        data_padded = [data_padded[i] | (data_padded[i+1] << 8) | (data_padded[i+2] << 16) | (data_padded[i+3] << 24) for i in range(0, len(data_padded), 4)]
        checksum = sum(data_padded) & 0xFFFFFFFF

        send_data = [0x27, mcu_addr & 0xFF, (mcu_addr >> 8) & 0xFF, (mcu_addr >> 16) & 0xFF, data_len & 0xFF, (data_len >> 8) & 0xFF, (data_len >> 16) & 0xFF]
        self.clear_input_buffer()
        self.serial_port.write(bytes(send_data))

        recv_data = []
        startTime = time.monotonic()
        timeLimit = 3
        while time.monotonic() - startTime < timeLimit:
            while self.serial_port.in_waiting > 0:
                oneChar = self.serial_port.read(1)
                recv_data.append(int(oneChar[0]))
                if len(recv_data) > 5:
                    recv_data = recv_data[1:]
                if len(recv_data) == 5:
                    if recv_data[0] == 0x27:
                        received_checksum = (recv_data[1] | (recv_data[2] << 8) | (recv_data[3] << 16) | (recv_data[4] << 24)) & 0xFFFFFFFF
                        if received_checksum == checksum:
                            return True

            time.sleep(0.001)
        return False
    
    def erase_block(self, mcu_addr, block_size):
        self.clear_input_buffer()
        block_count = (block_size + 4095) // 4096
        self.serial_port.write(bytes([0x17, mcu_addr & 0xFF, (mcu_addr >> 8) & 0xFF, (mcu_addr >> 16) & 0xFF, block_count&0xFF, (block_count >> 8) & 0xFF]))
        ret = self.wait_for_response_char(b'\x06', timeout=15)
        if ret == False:
            print("erase block failed")
            return False
        return True
    
    def load_flash_loader(self):
        ret = self.change_baudrate(230400)
        if ret == False:
            print("change baudrate failed")
            return False
        ret = self.write_block(self.flash_loader_addr, self.flash_loader)
        if ret == False:
            print("write block failed")
            return False
        self.clear_input_buffer()
        self.serial_port.write(b'\x04')
        ret = self.wait_for_response_char(b'\x06')
        if ret == False:
            print("trigger download 2 failed")
            return False
        self.serial_port.baudrate = 115200
        ret = self.wait_for_sync(1)
        if ret == False:
            print("wait for sync after trigger download 2 failed")
            return False
        return True


    def erase_4M_flash(self):
        self.enter_bootloader()
        ret = self.wait_for_sync(2)
        if ret == False:
            print("wait for sync failed")
            return False
        ret = self.load_flash_loader()
        if ret == False:
            print("load flash loader failed")
            return False
        self.clear_input_buffer()
        # erase flash.
        self.serial_port.write(b'\x26\x01\x01\x00')
        ret = self.wait_for_response_char(b'\x06')
        if ret == False:
            print("erase flash failed")
            return False
        ret = self.erase_block(0x8000000, 4*1024*1024)
        if ret == False:
            print("erase block full failed")
            return False

        return True
    
    def flash_4M_flash(self, bootloader_km0_path, bootloader_km4_path, image_path):
        if not os.path.exists(bootloader_km0_path):
            print(f"bootloader km0 file {bootloader_km0_path} not found")
            return False
        if not os.path.exists(bootloader_km4_path):
            print(f"bootloader km4 file {bootloader_km4_path} not found")
            return False
        if not os.path.exists(image_path):
            print(f"image file {image_path} not found")
            return False
        

        with open(bootloader_km0_path, "rb") as f:
            km0_booloader = list(f.read())
            km0_booloader_addr = 0x08000000

        with open(bootloader_km4_path, "rb") as f:
            km4_booloader = list(f.read())
            km4_booloader_addr = 0x08004000

        with open(image_path, "rb") as f:
            image = list(f.read())
            image_addr = 0x08006000

        self.enter_bootloader()
        ret = self.wait_for_sync(2)
        if ret == False:
            print("wait for sync failed")
            return False
        ret = self.load_flash_loader()
        if ret == False:
            print("load flash loader failed")
            return False
        self.clear_input_buffer()
        # erase flash.
        self.serial_port.write(b'\x26\x01\x01\x00')
        ret = self.wait_for_response_char(b'\x06')
        if ret == False:
            print("erase flash failed")
            return False
        
        ret = self.erase_block(km0_booloader_addr, len(km0_booloader))
        if ret == False:
            print("erase block km0 failed")
            return False
        ret = self.erase_block(km4_booloader_addr, len(km4_booloader))
        if ret == False:
            print("erase block km4 failed")
            return False
        ret = self.erase_block(image_addr, len(image))
        if ret == False:
            print("erase block image failed")
            return False
        ret = self.erase_block(image_addr+0x200000, len(image))
        if ret == False:
            print("erase block image2 failed")
            return False
        
        self.id = 1
        ret = self.change_baudrate(1500000)
        if ret == False:
            print("change baudrate to 1500000 failed")
            return False

        ret = self.write_block(km0_booloader_addr, km0_booloader)
        if ret == False:
            print("write block km0 failed")
            return False
        ret = self.write_block(km4_booloader_addr, km4_booloader)
        if ret == False:
            print("write block km4 failed")
            return False
        ret = self.write_block(image_addr, image)
        if ret == False:
            print("write block image failed")
            return False
        
        self.clear_input_buffer()
        self.serial_port.write(b'\x04')
        ret = self.wait_for_response_char(b'\x06')
        if ret == False:
            print("write finish failed")
            return False
        self.serial_port.baudrate = 115200
        ret = self.wait_for_sync(2)
        if ret == False:
            print("wait for sync after write finish failed")
            return False
        
        #verify flash
        ret = self.verify_block(km0_booloader_addr, km0_booloader)
        if ret == False:
            print("verify block km0 failed")
            return False
        ret = self.verify_block(km4_booloader_addr, km4_booloader)
        if ret == False:
            print("verify block km4 failed")
            return False
        ret = self.verify_block(image_addr, image)
        if ret == False:
            print("verify block image failed")
            return False
        
        return True
    
    def flash_4M_flash_with_path_and_offset(self, named_tuple_of_path_and_offset):
        section_count = len(named_tuple_of_path_and_offset)
        #check if files exist
        for section in named_tuple_of_path_and_offset:
            if not os.path.exists(section.binary_file_path):
                print(f"file {section.binary_file_path} not found")
                return False
        file_content = []
        for section in named_tuple_of_path_and_offset:
            with open(section.binary_file_path, "rb") as f:
                file_content.append(list(f.read()))
        if section_count == 3:
            km0_booloader = file_content[0]
            km0_booloader_addr = 0x08000000
            km4_booloader = file_content[1]
            km4_booloader_addr = 0x08004000
            image = file_content[2]
            image_addr = 0x08006000
        else:
            return False

        self.enter_bootloader()
        ret = self.wait_for_sync(2)
        if ret == False:
            print("wait for sync failed")
            return False
        ret = self.load_flash_loader()
        if ret == False:
            print("load flash loader failed")
            return False
        self.clear_input_buffer()
        # erase flash.
        self.serial_port.write(b'\x26\x01\x01\x00')
        ret = self.wait_for_response_char(b'\x06')
        if ret == False:
            print("erase flash failed")
            return False

        ret = self.erase_block(km0_booloader_addr, len(km0_booloader))
        if ret == False:
            print("erase block km0 failed")
            return False
        ret = self.erase_block(km4_booloader_addr, len(km4_booloader))
        if ret == False:
            print("erase block km4 failed")
            return False
        ret = self.erase_block(image_addr, len(image))
        if ret == False:
            print("erase block image failed")
            return False
        ret = self.erase_block(image_addr+0x200000, len(image))
        if ret == False:
            print("erase block image2 failed")
            return False

        self.id = 1
        ret = self.change_baudrate(1500000)
        if ret == False:
            print("change baudrate to 1500000 failed")
            return False

        ret = self.write_block(km0_booloader_addr, km0_booloader)
        if ret == False:
            print("write block km0 failed")
            return False
        ret = self.write_block(km4_booloader_addr, km4_booloader)
        if ret == False:
            print("write block km4 failed")
            return False
        ret = self.write_block(image_addr, image)
        if ret == False:
            print("write block image failed")
            return False

        self.clear_input_buffer()
        self.serial_port.write(b'\x04')
        ret = self.wait_for_response_char(b'\x06')
        if ret == False:
            print("write finish failed")
            return False
        self.serial_port.baudrate = 115200
        ret = self.wait_for_sync(2)
        if ret == False:
            print("wait for sync after write finish failed")
            return False

        #verify flash
        ret = self.verify_block(km0_booloader_addr, km0_booloader)
        if ret == False:
            print("verify block km0 failed")
            return False
        ret = self.verify_block(km4_booloader_addr, km4_booloader)
        if ret == False:
            print("verify block km4 failed")
            return False
        ret = self.verify_block(image_addr, image)
        if ret == False:
            print("verify block image failed")
            return False

        return True

    def flash_4M_flash_with_path_and_offset(self, named_tuple_of_path_and_offset):
        section_count = len(named_tuple_of_path_and_offset)
        #check if files exist
        for section in named_tuple_of_path_and_offset:
            if not os.path.exists(section.binary_file_path):
                print(f"file {section.binary_file_path} not found")
                return False
        file_content = []
        for section in named_tuple_of_path_and_offset:
            with open(section.binary_file_path, "rb") as f:
                file_content.append(list(f.read()))

        self.enter_bootloader()
        ret = self.wait_for_sync(2)
        if ret == False:
            print("wait for sync failed")
            return False
        ret = self.load_flash_loader()
        if ret == False:
            print("load flash loader failed")
            return False
        self.clear_input_buffer()
        # erase flash.
        self.serial_port.write(b'\x26\x01\x01\x00')
        ret = self.wait_for_response_char(b'\x06')
        if ret == False:
            print("erase flash failed")
            return False
        
        for i in range(section_count):
            section = named_tuple_of_path_and_offset[i]
            addr = section.start_address
            data = file_content[i]
            basename = os.path.basename(section.binary_file_path)
            print(f"erase block {basename} addr: {hex(addr)} len: {len(data)}")
            ret = self.erase_block(addr, len(data))
            if ret == False:
                print(f"erase block {basename} failed")
                return False
            if addr == 0x08006000:
                print(f"erase block image2 addr: 0x08006000+0x200000 len: {len(data)}")
                ret = self.erase_block(addr + 0x200000, len(data))
                if ret == False:
                    print(f"erase block image2 failed")
                    return False
        
        self.id = 1
        ret = self.change_baudrate(1500000)
        if ret == False:
            print("change baudrate to 1500000 failed")
            return False
        
        for i in range(section_count):
            section = named_tuple_of_path_and_offset[i]
            addr = section.start_address
            data = file_content[i]
            basename = os.path.basename(section.binary_file_path)
            print(f"write block {basename} addr: {hex(addr)} len: {len(data)}")
            ret = self.write_block(addr, data)
            if ret == False:
                print(f"write block {basename} failed")
                return False
        
        self.clear_input_buffer()
        self.serial_port.write(b'\x04')
        ret = self.wait_for_response_char(b'\x06')
        if ret == False:
            print("write finish failed")
            return False
        self.serial_port.baudrate = 115200
        ret = self.wait_for_sync(2)
        if ret == False:
            print("wait for sync after write finish failed")
            return False
        
        #verify flash
        for i in range(section_count):
            section = named_tuple_of_path_and_offset[i]
            addr = section.start_address
            data = file_content[i]
            basename = os.path.basename(section.binary_file_path)
            print(f"verify block {basename} addr: {hex(addr)} len: {len(data)}")
            ret = self.verify_block(addr, data)
            if ret == False:
                print(f"verify block {basename} failed")
                return False
        
        return True
        